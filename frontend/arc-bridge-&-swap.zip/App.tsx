import React, { useState, useMemo } from 'react';
import { Asset, UserBalance, Transaction, TransactionType } from './types';
import { ASSETS } from './constants';
import Header from './components/Header';
import Bridge from './components/Bridge';
import Swap from './components/Swap';
import History from './components/History';

type ActiveView = 'bridge' | 'swap' | 'history';

const App: React.FC = () => {
    const [activeView, setActiveView] = useState<ActiveView>('bridge');
    const [walletAddress, setWalletAddress] = useState<string | null>(null);

    const [assets] = useState<Asset[]>(ASSETS);
    const [userBalances, setUserBalances] = useState<UserBalance[]>([
        { assetId: 'eth', amount: 10, network: 'sepolia' },
        { assetId: 'usdc', amount: 5000, network: 'sepolia' },
        { assetId: 'eth', amount: 2, network: 'arc_testnet' },
    ]);
    const [transactions, setTransactions] = useState<Transaction[]>([]);

    const connectWallet = () => {
        setWalletAddress('0x1a2b...c3d4');
    };

    const updateBalance = (
        setter: React.Dispatch<React.SetStateAction<UserBalance[]>>,
        network: 'sepolia' | 'arc_testnet',
        assetId: string,
        change: number
    ) => {
        setter(prev => {
            const existingIndex = prev.findIndex(b => b.assetId === assetId && b.network === network);
            if (existingIndex > -1) {
                const next = [...prev];
                next[existingIndex] = { ...next[existingIndex], amount: next[existingIndex].amount + change };
                return next;
            } else {
                return [...prev, { assetId, amount: change, network }];
            }
        });
    };

    const handleBridge = (fromNetwork: string, toNetwork: string, asset: Asset, amount: number) => {
        const fromBalance = userBalances.find(b => b.assetId === asset.id && b.network === (fromNetwork as any))?.amount || 0;
        if (amount > fromBalance) {
            alert('Insufficient balance');
            return;
        }

        updateBalance(setUserBalances, fromNetwork as any, asset.id, -amount);
        updateBalance(setUserBalances, toNetwork as any, asset.id, amount);

        const newTransaction: Transaction = {
            id: `${Date.now()}`,
            type: TransactionType.BRIDGE,
            fromNetwork,
            toNetwork,
            fromAsset: asset,
            fromAmount: amount,
            toAsset: asset,
            toAmount: amount,
            timestamp: new Date(),
        };
        setTransactions(prev => [newTransaction, ...prev]);
        alert(`Bridged ${amount} ${asset.symbol} from ${fromNetwork} to ${toNetwork}`);
    };
    
    const handleSwap = (fromAsset: Asset, toAsset: Asset, fromAmount: number) => {
        const fromBalance = userBalances.find(b => b.assetId === fromAsset.id && b.network === 'sepolia')?.amount || 0;
        if (fromAmount > fromBalance) {
            alert("Insufficient balance");
            return;
        }

        const toAmount = (fromAmount * fromAsset.priceUSD) / toAsset.priceUSD * 0.999; // 0.1% fee

        updateBalance(setUserBalances, 'sepolia', fromAsset.id, -fromAmount);
        updateBalance(setUserBalances, 'sepolia', toAsset.id, toAmount);
        
        const newSwapTransaction: Transaction = {
            id: `${Date.now()}`,
            type: TransactionType.SWAP,
            fromNetwork: 'Sepolia',
            toNetwork: 'Sepolia',
            fromAsset,
            fromAmount,
            toAsset,
            toAmount,
            timestamp: new Date(),
        };
        setTransactions(prev => [newSwapTransaction, ...prev]);
        
        alert(`Swapped ${fromAmount.toFixed(4)} ${fromAsset.symbol} for ${toAmount.toFixed(4)} ${toAsset.symbol}`);
    };

    const content = useMemo(() => {
        switch(activeView) {
            case 'bridge': return <Bridge assets={assets} userBalances={userBalances} onBridge={handleBridge} />;
            case 'swap': return <Swap assets={assets} userBalances={userBalances} onSwap={handleSwap} />;
            case 'history': return <History transactions={transactions} />;
            default: return <Bridge assets={assets} userBalances={userBalances} onBridge={handleBridge} />;
        }
    }, [activeView, assets, userBalances, transactions]);

    return (
        <div className="min-h-screen bg-arc-dark-900 text-arc-text-primary">
            <Header
                walletAddress={walletAddress}
                onConnectWallet={connectWallet}
                activeView={activeView}
                setActiveView={setActiveView}
            />
            <main className="container mx-auto px-4 py-8">
                {walletAddress ? content : (
                    <div className="text-center py-20">
                        <h2 className="text-3xl font-bold mb-4">Welcome to ARC Bridge</h2>
                        <p className="text-arc-text-secondary mb-8">Connect your wallet to start bridging and swapping assets.</p>
                        <button
                            onClick={connectWallet}
                            className="bg-arc-accent-primary hover:bg-opacity-80 text-white font-bold py-3 px-6 rounded-lg transition-colors"
                        >
                            Connect Wallet
                        </button>
                    </div>
                )}
            </main>
        </div>
    );
};

export default App;
