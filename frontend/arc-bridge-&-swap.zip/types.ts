// FIX: Add ModalType enum, which is used in InteractionModal and AssetRow.
export enum ModalType {
    SUPPLY = 'SUPPLY',
    WITHDRAW = 'WITHDRAW',
    BORROW = 'BORROW',
    REPAY = 'REPAY',
}

export interface Asset {
  id: string;
  name: string;
  symbol: string;
  icon: string;
  priceUSD: number;
  isBridgeable?: boolean;
  // FIX: Add optional properties for lending features to fix type errors in Dashboard.tsx.
  isCollateral?: boolean;
  liquidationThreshold?: number;
}

export type UserBalance = {
  assetId: string;
  amount: number;
  network: 'sepolia' | 'arc_testnet';
};

export enum TransactionType {
    BRIDGE = 'Bridge',
    SWAP = 'Swap'
}

export interface Transaction {
    id:string;
    type: TransactionType;
    fromAsset: Asset;
    fromAmount: number;
    toAsset: Asset;
    toAmount: number;
    fromNetwork?: string;
    toNetwork?: string;
    timestamp: Date;
}