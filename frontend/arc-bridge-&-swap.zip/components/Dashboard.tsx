import React from 'react';
import { Asset, UserBalance } from '../types';
import AssetRow from './AssetRow';

interface DashboardProps {
    assets: Asset[];
    userSupplies: UserBalance[];
    userBorrows: UserBalance[];
    openModal: Function;
}

const Dashboard: React.FC<DashboardProps> = ({ assets, userSupplies, userBorrows, openModal }) => {
    // FIX: Explicitly type assetMap to ensure correct type inference.
    const assetMap: Map<string, Asset> = new Map(assets.map(a => [a.id, a]));

    const totalSuppliedUSD = userSupplies.reduce((acc, { assetId, amount }) => {
        const asset = assetMap.get(assetId);
        return acc + (asset ? asset.priceUSD * amount : 0);
    }, 0);

    const totalBorrowedUSD = userBorrows.reduce((acc, { assetId, amount }) => {
        const asset = assetMap.get(assetId);
        return acc + (asset ? asset.priceUSD * amount : 0);
    }, 0);
    
    const collateralValue = userSupplies.reduce((acc, {assetId, amount}) => {
        const asset = assetMap.get(assetId);
        // FIX: Check for liquidationThreshold existence since it's an optional property.
        if (asset && asset.isCollateral && typeof asset.liquidationThreshold === 'number') {
            return acc + (asset.priceUSD * amount * asset.liquidationThreshold);
        }
        return acc;
    }, 0);

    const healthFactor = totalBorrowedUSD > 0 ? collateralValue / totalBorrowedUSD : Infinity;
    
    const netWorth = totalSuppliedUSD - totalBorrowedUSD;
    
    const suppliedAssets = userSupplies.map(s => assetMap.get(s.assetId)).filter(Boolean) as Asset[];
    const borrowedAssets = userBorrows.map(b => assetMap.get(b.assetId)).filter(Boolean) as Asset[];

    const formatCurrency = (value: number) => `$${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    const getHealthFactorColor = (hf: number) => {
        if (hf > 2) return 'text-green-400';
        if (hf > 1.2) return 'text-yellow-400';
        return 'text-red-500';
    };

    const getHealthBarColor = (hf: number) => {
        if (hf === Infinity || hf > 2) return 'bg-green-500';
        if (hf > 1.2) return 'bg-yellow-500';
        return 'bg-red-500';
    };

    const getHealthBarWidth = (hf: number) => {
        if (hf === Infinity) return 100;
        // Scale so that HF of 2.5 is 100%. Cap at 100%.
        return Math.min((hf / 2.5) * 100, 100);
    };


    return (
        <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-arc-dark-800 p-6 rounded-lg border border-arc-dark-700">
                    <h3 className="text-arc-text-secondary text-sm">Net Worth</h3>
                    <p className="text-3xl font-bold">{formatCurrency(netWorth)}</p>
                </div>
                <div className="bg-arc-dark-800 p-6 rounded-lg border border-arc-dark-700">
                    <h3 className="text-arc-text-secondary text-sm">Health Factor</h3>
                    <p className={`text-3xl font-bold ${getHealthFactorColor(healthFactor)}`}>{healthFactor === Infinity ? '∞' : healthFactor.toFixed(2)}</p>
                     <div className="mt-2">
                        <div className="w-full bg-arc-dark-900 rounded-full h-2.5">
                            <div
                                className={`h-2.5 rounded-full ${getHealthBarColor(healthFactor)}`}
                                style={{ width: `${getHealthBarWidth(healthFactor)}%` }}
                            ></div>
                        </div>
                    </div>
                    <div className="h-4 mt-2 text-xs">
                        {healthFactor < 1 && healthFactor !== Infinity && (
                            <p className="text-red-500 font-bold animate-pulse">
                                CRITICAL: Liquidation risk imminent.
                            </p>
                        )}
                        {healthFactor >= 1 && healthFactor < 1.2 && (
                            <p className="text-yellow-500">
                                Liquidation risk is high.
                            </p>
                        )}
                    </div>
                </div>
                <div className="bg-arc-dark-800 p-6 rounded-lg border border-arc-dark-700">
                    <h3 className="text-arc-text-secondary text-sm">Net APY</h3>
                    <p className="text-3xl font-bold text-green-400">+...%</p>
                </div>
            </div>
            
            <div className="space-y-6">
                <PositionTable title="Your Supplies" assets={suppliedAssets} positions={userSupplies} openModal={openModal} type="supply" />
                <PositionTable title="Your Borrows" assets={borrowedAssets} positions={userBorrows} openModal={openModal} type="borrow" />
            </div>
        </div>
    );
};

interface PositionTableProps {
    title: string;
    assets: Asset[];
    positions: UserBalance[];
    openModal: Function;
    type: 'supply' | 'borrow';
}

const PositionTable: React.FC<PositionTableProps> = ({ title, assets, positions, openModal, type }) => {
    if (assets.length === 0) return null;
    
    return (
        <div className="bg-arc-dark-800 rounded-lg border border-arc-dark-700 overflow-hidden">
            <h2 className="text-xl font-bold p-6">{title}</h2>
            <table className="w-full text-left">
                <thead className="bg-arc-dark-700 text-arc-text-secondary text-xs uppercase tracking-wider">
                    <tr>
                        <th className="p-4">Asset</th>
                        <th className="p-4 text-right">Balance</th>
                        <th className="p-4 text-right">APY</th>
                        <th className="p-4 text-center">Collateral</th>
                        <th className="p-4"></th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-arc-dark-700">
                    {assets.map(asset => (
                        <AssetRow
                            key={asset.id}
                            asset={asset}
                            balance={positions.find(p => p.assetId === asset.id)?.amount || 0}
                            openModal={openModal}
                            isPosition={true}
                            type={type}
                        />
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default Dashboard;