import React, { useState } from 'react';
import { Asset, ModalType } from '../types';

interface InteractionModalProps {
    isOpen: boolean;
    onClose: () => void;
    asset: Asset;
    modalType: ModalType;
    userWalletBalance: number;
    userSupplyBalance: number;
    userBorrowBalance: number;
    onSubmit: (asset: Asset, amount: number, type: ModalType) => void;
    availableBorrowUSD: number;
}

const InteractionModal: React.FC<InteractionModalProps> = ({
    isOpen,
    onClose,
    asset,
    modalType,
    userWalletBalance,
    userSupplyBalance,
    userBorrowBalance,
    onSubmit,
    availableBorrowUSD,
}) => {
    const [amount, setAmount] = useState('');

    if (!isOpen) return null;

    const getTitle = () => {
        switch (modalType) {
            case ModalType.SUPPLY: return `Supply ${asset.symbol}`;
            case ModalType.WITHDRAW: return `Withdraw ${asset.symbol}`;
            case ModalType.BORROW: return `Borrow ${asset.symbol}`;
            case ModalType.REPAY: return `Repay ${asset.symbol}`;
        }
    };

    const getMaxAmount = () => {
        switch (modalType) {
            case ModalType.SUPPLY: return userWalletBalance;
            case ModalType.WITHDRAW: return userSupplyBalance;
            case ModalType.BORROW:
                if (asset.priceUSD <= 0) return 0;
                return availableBorrowUSD / asset.priceUSD;
            case ModalType.REPAY: return Math.min(userWalletBalance, userBorrowBalance);
        }
    };

    const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        if (/^\d*\.?\d*$/.test(value)) {
            setAmount(value);
        }
    };
    
    const handleSetMax = () => {
        setAmount(getMaxAmount().toString());
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(asset, parseFloat(amount), modalType);
    };

    const getButtonText = () => {
        switch (modalType) {
            case ModalType.SUPPLY: return 'Supply';
            case ModalType.WITHDRAW: return 'Withdraw';
            case ModalType.BORROW: return 'Borrow';
            case ModalType.REPAY: return 'Repay';
        }
    }
    
    const maxAmount = getMaxAmount();
    const amountNum = parseFloat(amount);
    const isAmountInvalid = isNaN(amountNum) || amountNum <= 0 || amountNum > maxAmount;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 transition-opacity">
            <div className="bg-arc-dark-800 rounded-lg border border-arc-dark-700 w-full max-w-md m-4">
                <div className="flex justify-between items-center p-6 border-b border-arc-dark-700">
                    <h2 className="text-xl font-bold">{getTitle()}</h2>
                    <button onClick={onClose} className="text-arc-text-secondary hover:text-white">&times;</button>
                </div>
                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                    <div>
                        <div className="flex justify-between items-baseline">
                            <label className="text-sm text-arc-text-secondary">Amount</label>
                            <span className="text-xs text-arc-text-secondary">Available: {maxAmount.toFixed(4)} {asset.symbol}</span>
                        </div>
                        <div className="relative mt-1">
                            <input
                                type="text"
                                value={amount}
                                onChange={handleAmountChange}
                                placeholder="0.0"
                                className="w-full bg-arc-dark-900 border border-arc-dark-700 rounded-md p-3 focus:ring-2 focus:ring-arc-accent-primary focus:outline-none"
                            />
                            <button type="button" onClick={handleSetMax} className="absolute right-3 top-1/2 -translate-y-1/2 text-xs bg-arc-accent-primary/20 text-arc-accent-primary px-2 py-1 rounded">MAX</button>
                        </div>
                    </div>

                    <div className="text-sm space-y-2 text-arc-text-secondary">
                         <div className="flex justify-between"><span>Wallet Balance</span> <span>{userWalletBalance.toFixed(4)} {asset.symbol}</span></div>
                         <div className="flex justify-between"><span>Supply Balance</span> <span>{userSupplyBalance.toFixed(4)} {asset.symbol}</span></div>
                         <div className="flex justify-between"><span>Borrow Balance</span> <span>{userBorrowBalance.toFixed(4)} {asset.symbol}</span></div>
                    </div>
                    
                    <button
                        type="submit"
                        disabled={isAmountInvalid}
                        className="w-full bg-arc-accent-primary text-white font-bold py-3 rounded-lg disabled:bg-arc-dark-700 disabled:text-arc-text-secondary disabled:cursor-not-allowed hover:bg-opacity-80 transition-colors"
                    >
                        {getButtonText()}
                    </button>
                </form>
            </div>
        </div>
    );
};

export default InteractionModal;
