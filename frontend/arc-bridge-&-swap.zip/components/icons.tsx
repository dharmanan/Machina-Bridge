
import React from 'react';

export const ArcIcon = ({ className = 'w-auto h-8' }: { className?: string }) => (
  <svg className={className} viewBox="0 0 100 32" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="arcGradient" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" style={{ stopColor: '#E0E0E0' }} />
        <stop offset="100%" style={{ stopColor: '#A0A0A0' }} />
      </linearGradient>
    </defs>
    <path
      d="M4.33,22.34 C3.2,14.23 8.36,4.2 16.5,4.2 C24.64,4.2 29.8,14.23 28.67,22.34 L23.5,22.34 C24.3,15.6 21.0,8.5 16.5,8.5 C12.0,8.5 8.7,15.6 9.5,22.34 L4.33,22.34 Z"
      fill="url(#arcGradient)"
    />
    <text x="38" y="23" fontFamily="sans-serif" fontSize="18" fontWeight="bold" fill="url(#arcGradient)">
      Arc
    </text>
  </svg>
);


export const EthIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2L11.5 3.5L6 9.5L12 13L18 9.5L12.5 3.5L12 2Z" fill="#343434"/>
        <path d="M12 14.5L6 10.5L12 22V14.5Z" fill="#8C8C8C"/>
        <path d="M12 14.5L18 10.5L12 22V14.5Z" fill="#3C3C3B"/>
        <path d="M6 9.5L12 13L12 14.5L6 10.5L6 9.5Z" fill="#141414"/>
        <path d="M18 9.5L12 13L12 14.5L18 10.5L18 9.5Z" fill="#141414"/>
    </svg>
);

export const BtcIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} fill="#F7931A" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 24C18.6274 24 24 18.6274 24 12C24 5.37258 18.6274 0 12 0C5.37258 0 0 5.37258 0 12C0 18.6274 5.37258 24 12 24ZM10.0211 7.23438H14.1562C15.0604 7.23438 15.7552 7.375 16.2409 7.65625C16.7351 7.92844 17.0625 8.35937 17.224 8.94906C17.3942 9.53006 17.4792 10.2281 17.4792 11.0437C17.4792 11.8955 17.3984 12.6094 17.2375 13.1853C17.0853 13.7525 16.7681 14.1875 16.2859 14.4903C15.8125 14.7844 15.1278 14.9312 14.2312 14.9312H12.3844V17.7563H10.0211V7.23438ZM12.3844 9.09687V13.0687H14.0094C14.717 13.0687 15.228 12.9641 15.5415 12.7547C15.8638 12.5366 16.025 12.1812 16.025 11.6881C16.025 11.2313 15.8778 10.875 15.5837 10.6191C15.2984 10.3544 14.7937 10.2219 14.0706 10.2219H12.3844V9.09687Z"/>
    </svg>
);

export const UsdcIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="12" cy="12" r="12" fill="#2775CA"/>
        <path d="M12 18.5C15.5899 18.5 18.5 15.5899 18.5 12C18.5 8.41015 15.5899 5.5 12 5.5C8.41015 5.5 5.5 8.41015 5.5 12C5.5 15.5899 8.41015 18.5 12 18.5Z" fill="white"/>
        <path d="M13.3164 15.1311H14.7354C14.5494 16.0071 14.0274 16.6671 13.1694 17.1111C12.3114 17.5551 11.2314 17.6571 10.2054 17.4171C9.17937 17.1771 8.35137 16.6191 7.72137 15.7431C7.09137 14.8671 6.78537 13.7871 6.80337 12.6411C6.79437 11.4531 7.11837 10.3371 7.77537 9.49108C8.43237 8.64508 9.32937 8.01508 10.3434 7.69108C11.3574 7.36708 12.4374 7.35808 13.4394 7.66408C14.0154 7.84408 14.4954 8.24008 14.7594 8.75008L13.5294 9.53008C13.3674 9.25408 13.0974 9.02608 12.7974 8.89108C12.0174 8.54008 11.0934 8.56708 10.3434 8.96008C9.59337 9.35308 9.10137 10.0521 8.98137 10.8801C8.86137 11.7081 9.12537 12.5781 9.69537 13.1931C10.2654 13.8081 11.0874 14.1201 11.9154 14.0241C12.5154 13.9521 13.0134 13.6311 13.3164 13.1511V11.8311H11.5794V10.3111H14.7594V13.8261C14.7594 14.2881 14.1564 14.9361 13.3164 15.1311Z" fill="#2775CA"/>
    </svg>
);

export const EurcIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="12" cy="12" r="12" fill="#003399"/>
        <text x="12" y="17" textAnchor="middle" fontSize="14" fontWeight="bold" fill="white">€</text>
    </svg>
);