import React from 'react';
import { ArcIcon } from './icons';

interface HeaderProps {
    walletAddress: string | null;
    onConnectWallet: () => void;
    activeView: string;
    setActiveView: (view: 'bridge' | 'swap' | 'history') => void;
}

const Header: React.FC<HeaderProps> = ({ walletAddress, onConnectWallet, activeView, setActiveView }) => {
    
    const NavLink: React.FC<{ view: 'bridge' | 'swap' | 'history', children: React.ReactNode }> = ({ view, children }) => (
        <button
            onClick={() => setActiveView(view)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeView === view
                    ? 'bg-arc-dark-700 text-white'
                    : 'text-arc-text-secondary hover:bg-arc-dark-800 hover:text-white'
            }`}
        >
            {children}
        </button>
    );

    const addArcTestnet = async () => {
        if (typeof (window as any).ethereum !== 'undefined') {
            try {
                await (window as any).ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: [{
                        chainId: '0x270F', // 9999
                        chainName: 'Arc Testnet',
                        nativeCurrency: {
                            name: 'Arc Ether',
                            symbol: 'ARETH',
                            decimals: 18,
                        },
                        rpcUrls: ['https://rpc-testnet.arcprotocol.io/'],
                        blockExplorerUrls: ['https://testnet.arcscan.app/'],
                    }],
                });
            } catch (error) {
                console.error("Could not add Arc Testnet to wallet:", error);
                alert("Failed to add Arc Testnet. Please check your wallet and try again.");
            }
        } else {
            alert('MetaMask or a compatible wallet is not installed.');
        }
    };

    return (
        <header className="bg-arc-dark-800 border-b border-arc-dark-700">
            <div className="container mx-auto px-4">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center space-x-8">
                        <div className="flex items-center">
                           <ArcIcon className="h-8 w-auto" />
                           <span className="ml-2 font-bold text-lg">ARC Bridge</span>
                        </div>
                        <nav className="hidden md:flex items-center space-x-4">
                           <NavLink view="bridge">Bridge</NavLink>
                           <NavLink view="swap">Swap</NavLink>
                           <NavLink view="history">History</NavLink>
                        </nav>
                    </div>
                    <div className="flex items-center space-x-4">
                        <a
                            href="https://www.sepoliafaucet.io/"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="border border-arc-accent-secondary text-arc-accent-secondary font-bold py-2 px-4 rounded-lg transition-colors hover:bg-arc-accent-secondary hover:text-white text-sm"
                        >
                            Sepolia Faucet
                        </a>
                        <button
                            onClick={addArcTestnet}
                            className="border border-arc-accent-primary text-arc-accent-primary font-bold py-2 px-4 rounded-lg transition-colors hover:bg-arc-accent-primary hover:text-white text-sm"
                        >
                            Add Arc Testnet
                        </button>
                        {walletAddress ? (
                            <div className="bg-arc-dark-700 text-arc-text-primary px-4 py-2 rounded-lg text-sm font-mono">
                                {walletAddress}
                            </div>
                        ) : (
                            <button
                                onClick={onConnectWallet}
                                className="bg-arc-accent-primary hover:bg-opacity-80 text-white font-bold py-2 px-4 rounded-lg transition-colors"
                            >
                                Connect Wallet
                            </button>
                        )}
                    </div>
                </div>
                 <nav className="md:hidden flex items-center justify-center space-x-4 pb-2">
                   <NavLink view="bridge">Bridge</NavLink>
                   <NavLink view="swap">Swap</NavLink>
                   <NavLink view="history">History</NavLink>
                </nav>
            </div>
        </header>
    );
};

export default Header;
