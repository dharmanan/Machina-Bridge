import React from 'react';
import { Asset, UserBalance } from '../types';
import AssetRow from './AssetRow';

interface MarketProps {
    assets: Asset[];
    userBalances: UserBalance[];
    openModal: Function;
}

const Market: React.FC<MarketProps> = ({ assets, userBalances, openModal }) => {
    return (
        <div className="space-y-12">
            <MarketTable 
                title="Assets to Supply" 
                assets={assets}
                userBalances={userBalances}
                openModal={openModal}
                type="supply"
            />
            <MarketTable 
                title="Assets to Borrow" 
                assets={assets}
                userBalances={userBalances}
                openModal={openModal}
                type="borrow"
            />
        </div>
    );
};

interface MarketTableProps {
    title: string;
    assets: Asset[];
    userBalances: UserBalance[];
    openModal: Function;
    type: 'supply' | 'borrow';
}

const MarketTable: React.FC<MarketTableProps> = ({ title, assets, userBalances, openModal, type }) => {
    return (
        <div className="bg-arc-dark-800 rounded-lg border border-arc-dark-700 overflow-hidden">
            <h2 className="text-xl font-bold p-6">{title}</h2>
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead className="bg-arc-dark-700 text-arc-text-secondary text-xs uppercase tracking-wider">
                        <tr>
                            <th className="p-4">Asset</th>
                            <th className="p-4 text-right">{type === 'supply' ? 'Supply APY' : 'Borrow APY'}</th>
                            <th className="p-4 text-right">Total Supplied</th>
                            <th className="p-4 text-right">Total Borrowed</th>
                            <th className="p-4 text-right">Wallet Balance</th>
                            <th className="p-4"></th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-arc-dark-700">
                        {assets.map(asset => (
                            <AssetRow
                                key={asset.id}
                                asset={asset}
                                balance={userBalances.find(b => b.assetId === asset.id)?.amount || 0}
                                openModal={openModal}
                                isPosition={false}
                                type={type}
                            />
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default Market;
