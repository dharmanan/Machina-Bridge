import React, { useState, useMemo } from 'react';
import { Asset, UserBalance } from '../types';
import { NETWORKS, ASSETS } from '../constants';

interface BridgeProps {
    assets: Asset[];
    userBalances: UserBalance[];
    onBridge: (fromNetwork: string, toNetwork: string, asset: Asset, amount: number) => void;
}

const NetworkSelector: React.FC<{
    label: string;
    selectedNetwork: string;
    onSelectNetwork: (networkId: string) => void;
    disabled?: boolean;
}> = ({ label, selectedNetwork, onSelectNetwork, disabled }) => {
    return (
        <div className="bg-arc-dark-900 p-4 rounded-lg">
            <span className="text-xs text-arc-text-secondary">{label}</span>
            <select
                value={selectedNetwork}
                onChange={(e) => onSelectNetwork(e.target.value)}
                disabled={disabled}
                className="bg-transparent text-lg w-full focus:outline-none mt-1"
            >
                {NETWORKS.map(net => (
                    <option key={net.id} value={net.id} className="bg-arc-dark-800">{net.name}</option>
                ))}
            </select>
        </div>
    );
};


const Bridge: React.FC<BridgeProps> = ({ assets, userBalances, onBridge }) => {
    const [fromNetwork, setFromNetwork] = useState('sepolia');
    const [toNetwork, setToNetwork] = useState('arc_testnet');
    const [amount, setAmount] = useState('');
    const [selectedAssetId, setSelectedAssetId] = useState('eth');

    const bridgeableAssets = useMemo(() => assets.filter(a => a.isBridgeable), [assets]);
    const selectedAsset = assets.find(a => a.id === selectedAssetId);

    const balance = useMemo(() => {
        return userBalances.find(b => b.assetId === selectedAssetId && b.network === (fromNetwork as any))?.amount || 0;
    }, [userBalances, selectedAssetId, fromNetwork]);

    const handleSwitchNetworks = () => {
        const temp = fromNetwork;
        setFromNetwork(toNetwork);
        setToNetwork(temp);
    };

    const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        if (/^\d*\.?\d*$/.test(value)) {
            setAmount(value);
        }
    };

    const handleMax = () => setAmount(balance.toString());

    const handleSubmit = () => {
        if (selectedAsset && amount) {
            onBridge(fromNetwork, toNetwork, selectedAsset, parseFloat(amount));
            setAmount('');
        }
    };

    const amountNum = parseFloat(amount);
    const isInvalidAmount = isNaN(amountNum) || amountNum <= 0 || amountNum > balance;

    return (
        <div className="max-w-md mx-auto bg-arc-dark-800 p-6 rounded-xl border border-arc-dark-700 space-y-4">
            <h2 className="text-xl font-bold text-center">Bridge</h2>

            <NetworkSelector label="From" selectedNetwork={fromNetwork} onSelectNetwork={setFromNetwork} />

            <div className="flex justify-center">
                <button onClick={handleSwitchNetworks} className="p-2 bg-arc-dark-700 rounded-full hover:bg-arc-dark-900 transition-transform transform hover:rotate-180">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 3a.75.75 0 01.75.75v10.5a.75.75 0 01-1.5 0V3.75A.75.75 0 0110 3z" clipRule="evenodd" />
                        <path fillRule="evenodd" d="M10 14a.75.75 0 01-.53-1.28l4.25-4.25a.75.75 0 011.06 1.06l-4.25 4.25A.75.75 0 0110 14z" clipRule="evenodd" />
                        <path fillRule="evenodd" d="M5.28 9.72a.75.75 0 011.06 0l4.25 4.25a.75.75 0 11-1.06 1.06L4.72 10.78a.75.75 0 010-1.06z" clipRule="evenodd" />
                    </svg>
                </button>
            </div>
            
            <NetworkSelector label="To" selectedNetwork={toNetwork} onSelectNetwork={setToNetwork} />

            <div className="bg-arc-dark-900 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-1">
                    <span className="text-xs text-arc-text-secondary">You send</span>
                    <span className="text-xs text-arc-text-secondary">Balance: {balance.toFixed(4)}</span>
                </div>
                <div className="flex justify-between items-center">
                    <input 
                        type="text" 
                        value={amount}
                        onChange={handleAmountChange}
                        placeholder="0.0"
                        className="bg-transparent text-2xl w-full focus:outline-none"
                    />
                    <div className="flex items-center space-x-2">
                        <button onClick={handleMax} className="text-xs bg-arc-accent-primary/20 text-arc-accent-primary px-2 py-1 rounded">MAX</button>
                        <select
                            value={selectedAssetId}
                            onChange={(e) => setSelectedAssetId(e.target.value)}
                            className="bg-arc-dark-700 p-2 rounded-md focus:outline-none"
                        >
                            {bridgeableAssets.map(asset => (
                                <option key={asset.id} value={asset.id} className="bg-arc-dark-800">{asset.symbol}</option>
                            ))}
                        </select>
                    </div>
                </div>
            </div>
            
            <button
                onClick={handleSubmit}
                disabled={isInvalidAmount}
                className="w-full bg-arc-accent-primary text-white font-bold py-3 rounded-lg disabled:bg-arc-dark-700 disabled:text-arc-text-secondary disabled:cursor-not-allowed hover:bg-opacity-80 transition-colors"
            >
                Bridge Asset
            </button>
        </div>
    );
};

export default Bridge;
