import React, { useState, useEffect } from 'react';
import { Asset, UserBalance } from '../types';

interface SwapProps {
    assets: Asset[];
    userBalances: UserBalance[];
    onSwap: (fromAsset: Asset, toAsset: Asset, fromAmount: number) => void;
}

const Swap: React.FC<SwapProps> = ({ assets, userBalances, onSwap }) => {
    const [fromAmount, setFromAmount] = useState<string>('');
    const [toAmount, setToAmount] = useState<string>('');
    
    const fromAsset = assets.find(a => a.id === 'eth');
    const toAsset = assets.find(a => a.id === 'usdc');
    
    // Swap only on Sepolia
    const fromBalance = userBalances.find(b => b.assetId === 'eth' && b.network === 'sepolia')?.amount || 0;

    useEffect(() => {
        if (fromAsset && toAsset && fromAmount) {
            const amount = parseFloat(fromAmount);
            if (!isNaN(amount) && amount > 0) {
                const result = (amount * fromAsset.priceUSD) / toAsset.priceUSD * 0.999; // 0.1% fee
                setToAmount(result.toFixed(2));
            } else {
                setToAmount('');
            }
        } else {
            setToAmount('');
        }
    }, [fromAmount, fromAsset, toAsset]);
    
    const handleFromAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        if (/^\d*\.?\d*$/.test(value)) {
            setFromAmount(value);
        }
    }
    
    const handleMax = () => {
        setFromAmount(fromBalance.toString());
    }
    
    const handleSubmit = () => {
        if(fromAsset && toAsset && fromAmount) {
            onSwap(fromAsset, toAsset, parseFloat(fromAmount));
            setFromAmount('');
        }
    }

    if (!fromAsset || !toAsset) return <div>Loading assets...</div>;

    const amountNum = parseFloat(fromAmount);
    const isInvalidAmount = isNaN(amountNum) || amountNum <= 0 || amountNum > fromBalance;

    return (
        <div className="max-w-md mx-auto bg-arc-dark-800 p-6 rounded-xl border border-arc-dark-700 space-y-4">
            <h2 className="text-xl font-bold text-center">Swap on Sepolia</h2>
            
            <SwapInput
                label="From"
                asset={fromAsset}
                amount={fromAmount}
                setAmount={handleFromAmountChange}
                balance={fromBalance}
                onMax={handleMax}
            />

            <div className="flex justify-center">
                <div className="p-2 bg-arc-dark-700 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                         <path fillRule="evenodd" d="M10 3a.75.75 0 01.75.75v10.5a.75.75 0 01-1.5 0V3.75A.75.75 0 0110 3z" clipRule="evenodd" />
                         <path fillRule="evenodd" d="M10 14a.75.75 0 01-.53-1.28l4.25-4.25a.75.75 0 011.06 1.06l-4.25 4.25A.75.75 0 0110 14z" clipRule="evenodd" />
                         <path fillRule="evenodd" d="M5.28 9.72a.75.75 0 011.06 0l4.25 4.25a.75.75 0 11-1.06 1.06L4.72 10.78a.75.75 0 010-1.06z" clipRule="evenodd" />
                    </svg>
                </div>
            </div>

            <SwapInput
                label="To"
                asset={toAsset}
                amount={toAmount}
                isReadOnly={true}
            />
            
            <p className="text-sm text-center text-arc-text-secondary">1 {fromAsset.symbol} ≈ {(fromAsset.priceUSD / toAsset.priceUSD).toFixed(2)} {toAsset.symbol}</p>

            <button
                onClick={handleSubmit}
                disabled={isInvalidAmount}
                className="w-full bg-arc-accent-primary text-white font-bold py-3 rounded-lg disabled:bg-arc-dark-700 disabled:text-arc-text-secondary disabled:cursor-not-allowed hover:bg-opacity-80 transition-colors"
            >
                Swap
            </button>
        </div>
    );
};

interface SwapInputProps {
    label: string;
    asset: Asset;
    amount: string;
    setAmount?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    balance?: number;
    onMax?: () => void;
    isReadOnly?: boolean;
}

const SwapInput: React.FC<SwapInputProps> = ({ label, asset, amount, setAmount, balance, onMax, isReadOnly = false}) => {
    return (
        <div className="bg-arc-dark-900 p-4 rounded-lg">
            <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-arc-text-secondary">{label}</span>
                {balance !== undefined && <span className="text-xs text-arc-text-secondary">Balance: {balance.toFixed(4)}</span>}
            </div>
            <div className="flex justify-between items-center">
                <input 
                    type="text" 
                    value={amount}
                    onChange={setAmount}
                    readOnly={isReadOnly}
                    placeholder="0.0"
                    className="bg-transparent text-2xl w-full focus:outline-none"
                />
                <div className="flex items-center space-x-2 bg-arc-dark-700 p-2 rounded-md font-bold">
                    <span>{asset.symbol}</span>
                </div>
            </div>
            {onMax && <div className="flex justify-end mt-2"><button onClick={onMax} className="text-xs bg-arc-accent-primary/20 text-arc-accent-primary px-2 py-1 rounded">MAX</button></div>}
        </div>
    );
};


export default Swap;
