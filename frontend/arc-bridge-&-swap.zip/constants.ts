import { Asset } from './types';

export const ASSETS: Asset[] = [
  {
    id: 'eth',
    name: 'Ethereum',
    symbol: 'ETH',
    icon: 'eth',
    priceUSD: 3500.00,
    isBridgeable: true,
  },
  {
    id: 'usdc',
    name: 'USD Coin',
    symbol: 'USDC',
    icon: 'usdc',
    priceUSD: 1.00,
    isBridgeable: false,
  },
];

export const NETWORKS = [
    { id: 'sepolia', name: 'Sepolia Testnet' },
    { id: 'arc_testnet', name: 'Arc Testnet' }
];
